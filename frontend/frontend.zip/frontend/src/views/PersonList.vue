<template>
  <div class="page-container">
    <h2>Group Members</h2>

    <button @click="isModalOpen = true" class="btn-primary">
        + Add New Member
    </button>
    
    <p v-if="loading">Loading members...</p>
    <p v-else-if="errorMessage" class="error">{{ errorMessage }}</p>
    <div v-else class="list-container">
        <div v-for="person in persons" :key="person.id" class="list-item">
            <span>{{ person.name }} ({{ person.email }})</span>
            <div class="actions">
                <button @click="editPerson(person)" class="btn-secondary">Edit</button>
                <button @click="deletePerson(person.id)" class="btn-danger">Delete</button>
            </div>
        </div>
        <p v-if="!persons.length && !loading">No members added yet.</p>
    </div>

    <div v-if="isModalOpen" class="modal">
      <div class="modal-content">
        <h3>{{ editingPerson.id ? 'Edit Member' : 'Add New Member' }}</h3>
        <input type="text" v-model="editingPerson.name" placeholder="Name" required />
        <input type="email" v-model="editingPerson.email" placeholder="Email" required />
        <button @click="savePerson" class="btn-primary">Save</button>
        <button @click="closeModal" class="btn-secondary">Cancel</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import personService from '@/services/person.service'; // Correct service import

const persons = ref([]);
const loading = ref(true);
const errorMessage = ref(null);
const isModalOpen = ref(false);
const initialPersonState = { id: null, name: '', email: '' };
const editingPerson = ref({ ...initialPersonState });

const fetchPersons = async () => {
  try {
    const response = await personService.getAll();
    persons.value = response.data;
    loading.value = false;
  } catch (error) {
    console.error('Failed to fetch persons:', error);
    errorMessage.value = 'Failed to load group members. Check if you are logged in.';
    loading.value = false;
  }
};

const closeModal = () => {
    isModalOpen.value = false;
    editingPerson.value = { ...initialPersonState }; // Reset form
};

const editPerson = (person) => {
    editingPerson.value = { ...person };
    isModalOpen.value = true;
};

const savePerson = async () => {
    try {
        if (editingPerson.value.id) {
            // Update existing
            await personService.update(editingPerson.value.id, editingPerson.value);
        } else {
            // Create new
            await personService.create(editingPerson.value);
        }
        await fetchPersons(); // Refresh list
        closeModal();
    } catch (error) {
        errorMessage.value = `Failed to save member: ${error.message}`;
        console.error('Failed to save person:', error);
    }
};

const deletePerson = async (id) => {
    if (confirm('Are you sure you want to delete this member?')) {
        try {
            await personService.delete(id);
            await fetchPersons(); // Refresh list
        } catch (error) {
            errorMessage.value = `Failed to delete member: ${error.message}`;
            console.error('Failed to delete person:', error);
        }
    }
};

onMounted(fetchPersons);
</script>

<style>
html, body {
  margin: 0;
  padding: 0;
  background: linear-gradient(135deg, #e3f2fd, #f1f8e9);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.page-container {
  padding: 40px;
  max-width: 900px;
  margin: 60px auto;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: #333;
}

h2 {
  text-align: center;
  font-size: 2rem;
  font-weight: 600;
  color: #0a68c7;
  margin-bottom: 30px;
}

.btn-primary {
  background-color: #0a68c7;
  color: #fff;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.3s ease, transform 0.1s ease;
}
.btn-primary:hover {
  background-color: #0959ad;
  transform: translateY(-1px);
}

.btn-secondary {
  background-color: #9e9e9e;
  color: #fff;
  border: none;
  padding: 8px 14px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.3s ease;
}
.btn-secondary:hover {
  background-color: #757575;
}

.btn-danger {
  background-color: #e74c3c;
  color: #fff;
  border: none;
  padding: 8px 14px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.3s ease;
}
.btn-danger:hover {
  background-color: #c0392b;
}

.error {
  color: #e74c3c;
  background: #fdecea;
  border: 1px solid #f5b7b1;
  padding: 10px;
  border-radius: 8px;
  margin-top: 15px;
  text-align: center;
  font-weight: 500;
}

.list-container {
  margin-top: 25px;
  background: #fafafa;
  border-radius: 12px;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.05);
  overflow: hidden;
}

.list-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 20px;
  border-bottom: 1px solid #eee;
  transition: background 0.2s ease;
}
.list-item:last-child {
  border-bottom: none;
}
.list-item:hover {
  background-color: #f0f7ff;
}

.actions {
  display: flex;
  gap: 10px;
}

/* MODAL STYLING */
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(50, 50, 50, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}

.modal-content {
  background: #fff;
  padding: 30px;
  border-radius: 14px;
  width: 90%;
  max-width: 420px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
  animation: fadeIn 0.3s ease-out;
}

.modal-content h3 {
  color: #0a68c7;
  margin-bottom: 20px;
  text-align: center;
  font-size: 1.3rem;
  font-weight: 600;
}

.modal-content input {
  width: 100%;
  padding: 10px 12px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s;
}
.modal-content input:focus {
  border-color: #0a68c7;
  outline: none;
  box-shadow: 0 0 0 2px rgba(10, 104, 199, 0.2);
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-15px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>

