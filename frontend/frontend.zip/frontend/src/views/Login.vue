<template>
  <div class="login-container">
    <div class="auth-card">
      <h2>Sign In</h2>
      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label for="username">Username:</label>
          <input type="text" id="username" v-model="username" required />
        </div>

        <div class="form-group">
          <label for="password">Password:</label>
          <input type="password" id="password" v-model="password" required />
        </div>

        <button type="submit" :disabled="loading">
          {{ loading ? 'Signing In...' : 'Login' }}
        </button>

        <p v-if="message" :class="isError ? 'error' : 'success'">
          {{ message }}
        </p>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import authService from '@/services/auth.service';

const router = useRouter();
const username = ref('');
const password = ref('');
const loading = ref(false);
const message = ref('');
const isError = ref(false);

const handleLogin = async () => {
  loading.value = true;
  message.value = '';
  isError.value = false;

  try {
    const response = await authService.login(username.value, password.value);
    message.value = 'Login successful!';
    isError.value = false;
    setTimeout(() => router.push('/expenses'), 1000);
  } catch (error) {
    console.error('Login failed:', error);
    isError.value = true;
    if (error.response && error.response.status === 401) {
      message.value = 'Invalid username or password.';
    } else if (error.response?.data?.message) {
      message.value = error.response.data.message;
    } else {
      message.value = 'An unexpected error occurred during login.';
    }
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
html, body {
  margin: 0;
  padding: 0;
  background: linear-gradient(135deg, #e3f2fd, #f1f8e9);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.login-container {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #74b9ff, #a29bfe);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.auth-card {
  background: #fff;
  padding: 2rem 2.5rem;
  border-radius: 12px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
  width: 100%;
  max-width: 400px;
  animation: fadeIn 0.5s ease;
}

.auth-card h2 {
  text-align: center;
  margin-bottom: 1.5rem;
  color: #333;
}

.form-group {
  margin-bottom: 1.2rem;
}

label {
  display: block;
  margin-bottom: 0.3rem;
  color: #444;
  font-weight: 500;
}

input {
  width: 100%;
  padding: 0.6rem 0.8rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 1rem;
  transition: border-color 0.2s;
}

input:focus {
  border-color: #0984e3;
  outline: none;
}

button {
  width: 100%;
  padding: 0.7rem;
  background: #0984e3;
  color: #fff;
  border: none;
  border-radius: 6px;
  font-size: 1rem;
  cursor: pointer;
  transition: background 0.2s, transform 0.1s;
}

button:hover {
  background: #74b9ff;
}

button:active {
  transform: scale(0.98);
}

button:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.error {
  color: #e74c3c;
  background: #fdecea;
  border: 1px solid #e0b4b4;
  padding: 0.5rem;
  border-radius: 6px;
  text-align: center;
  margin-top: 1rem;
}

.success {
  color: #2ecc71;
  background: #ecf9f1;
  border: 1px solid #a3e4c1;
  padding: 0.5rem;
  border-radius: 6px;
  text-align: center;
  margin-top: 1rem;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
