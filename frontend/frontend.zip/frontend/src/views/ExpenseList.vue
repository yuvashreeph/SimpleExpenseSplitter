<template>
  <div class="page-container">
    <h2>Group Expenses</h2>

    <p v-if="loading">Loading data...</p>
    <p v-else-if="errorMessage" class="error">{{ errorMessage }}</p>

    <div v-else>
      <p v-if="!members.length" class="warning">
        ⚠️ Please add members first using the Members tab before recording expenses.
      </p>

      <button v-if="members.length" class="btn-primary" @click="openExpenseModal">
        + Add New Expense
      </button>

      <div class="list-container mt-4">
        <p v-if="!expenses.length">No expenses recorded yet.</p>
        <div
          v-for="expense in expenses"
          :key="expense.id"
          class="list-item"
          @click="viewExpenseDetails(expense)"
        >
          <span>
            {{ expense.description }} - ${{ expense.amount.toFixed(2) }}
            (Paid by {{ getMemberName(expense.paidBy) }})
          </span>
          <span class="view-details">View Details &gt;</span>
        </div>
      </div>
    </div>

    <!-- ADD EXPENSE MODAL -->
    <div v-if="isModalOpen" class="modal">
      <div class="modal-content">
        <h3>Record New Expense</h3>
        <form @submit.prevent="saveExpense">
          <div class="form-group">
            <label>Description:</label>
            <input type="text" v-model="currentExpense.description" required />
          </div>

          <div class="form-group">
            <label>Amount:</label>
            <input
              type="number"
              v-model.number="currentExpense.amount"
              required
              min="0.01"
              step="0.01"
            />
          </div>

          <div class="form-group">
            <label>Paid By:</label>
            <select v-model="currentExpense.paidBy" required>
              <option :value="null" disabled>Select member who paid</option>
              <option
                v-for="member in members"
                :key="member.id"
                :value="member.id"
              >
                {{ member.name }}
              </option>
            </select>
          </div>

          <div class="form-group split-group">
            <label>Split Between (Select all participants):</label>
            <div class="checkbox-list">
              <div
                v-for="member in members"
                :key="member.id"
                class="checkbox-item"
                :class="{ selected: currentExpense.splitBetween.includes(member.id) }"
                @click="toggleMember(member.id)"
              >
                {{ member.name }}
              </div>
            </div>

            <p
              v-if="currentExpense.splitBetween.length === 0"
              class="warning-small"
            >
              Select at least one person to split the expense.
            </p>
          </div>

          <div class="modal-actions">
            <button
              type="submit"
              class="btn-primary"
              :disabled="
                !currentExpense.description ||
                !currentExpense.amount ||
                !currentExpense.paidBy ||
                currentExpense.splitBetween.length === 0
              "
            >
              Record Expense
            </button>
            <button type="button" @click="closeExpenseModal" class="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- EXPENSE DETAILS MODAL -->
    <div v-if="selectedExpense" class="modal">
      <div class="modal-content">
        <div class="modal-header">
          <h3>Expense Details</h3>
          <button class="close-btn" @click="selectedExpense = null">&times;</button>
        </div>

        <div class="details-list">
          <div class="detail-item">
            <strong>Description:</strong>
            <span>{{ selectedExpense.description }}</span>
          </div>
          <div class="detail-item">
            <strong>Amount:</strong>
            <span>${{ selectedExpense.amount.toFixed(2) }}</span>
          </div>
          <div class="detail-item">
            <strong>Paid By:</strong>
            <span>{{ getMemberName(selectedExpense.paidBy) }}</span>
          </div>
          <div class="detail-item">
            <strong>Split Between:</strong>
            <span>{{ selectedExpense.splitBetweenNames.join(', ') }}</span>
          </div>
          <div class="detail-item">
            <strong>Individual Share:</strong>
            <span>${{ selectedExpense.perPersonAmount.toFixed(2) }}</span>
          </div>
          <div class="detail-item">
            <strong>Recorded On:</strong>
            <span>{{ new Date(selectedExpense.createdAt).toLocaleDateString() }}</span>
          </div>
        </div>    

        <div class="modal-actions">
          <button type="button" @click="selectedExpense = null" class="btn-primary">
            Close
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import expenseService from '@/services/expense.service';
import personService from '@/services/person.service';

const router = useRouter();
const expenses = ref([]);
const members = ref([]);
const loading = ref(true);
const errorMessage = ref(null);
const isModalOpen = ref(false);
const selectedExpense = ref(null);

const initialExpenseState = {
  description: '',
  amount: null,
  paidBy: null,
  splitBetween: [],
};
const currentExpense = ref({ ...initialExpenseState });

const getMemberName = (id) => {
  const member = members.value.find((m) => m.id === id);
  return member ? member.name : 'Unknown';
};

const viewExpenseDetails = (expense) => {
  selectedExpense.value = expense;
};

const fetchExpenses = async () => {
  try {
    const response = await expenseService.getAll();
    expenses.value = response.data;
  } catch (error) {
    console.error('Failed to fetch expenses:', error);
    errorMessage.value =
      'Failed to load expenses. Check login and backend connection.';
  }
};

const fetchMembers = async () => {
  try {
    const response = await personService.getAll();
    members.value = response.data;
  } catch (error) {
    console.error('Failed to fetch members:', error);
    errorMessage.value =
      (errorMessage.value || '') + ' Could not load members list.';
  }
};

const initializeData = async () => {
  loading.value = true;
  errorMessage.value = null;
  await Promise.all([fetchExpenses(), fetchMembers()]);
  loading.value = false;
};

const openExpenseModal = () => {
  currentExpense.value = {
    ...initialExpenseState,
    splitBetween: members.value.map((m) => m.id),
  };
  isModalOpen.value = true;
};

const closeExpenseModal = () => {
  isModalOpen.value = false;
};

const saveExpense = async () => {
  try {
    const expenseToSave = {
      description: currentExpense.value.description,
      amount: currentExpense.value.amount,
      paidBy: currentExpense.value.paidBy,
      splitBetween: currentExpense.value.splitBetween,
    };

    await expenseService.create(expenseToSave);
    closeExpenseModal();
    await fetchExpenses();
  } catch (error) {
    console.error('Failed to save expense:', error.response ? error.response.data : error);

    if (error.response && error.response.status === 401) {
      errorMessage.value = 'Session expired. Please log in again.';
      router.push('/login');
    } else if (error.response && error.response.data) {
      errorMessage.value =
        'Validation Failed: ' +
        (error.response.data.message || JSON.stringify(error.response.data));
    } else {
      errorMessage.value = 'Failed to record expense. Check console for details.';
    }
  }
};

const toggleMember = (memberId) => {
  const index = currentExpense.value.splitBetween.indexOf(memberId);
  if (index === -1) {
    currentExpense.value.splitBetween.push(memberId);
  } else {
    currentExpense.value.splitBetween.splice(index, 1);
  }
};


onMounted(initializeData);
</script>

<style>
html, body {
  margin: 0;
  padding: 0;
  background: linear-gradient(135deg, #e3f2fd, #f1f8e9);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.page-container {
  padding: 30px;
  max-width: 900px;
  margin: 50px auto;
  background: white;
  border-radius: 15px;
  box-shadow: 0 6px 25px rgba(0, 0, 0, 0.08);
  position: relative;
  font-family: 'Inter', sans-serif;
  color: #333;
}

body {
  background: linear-gradient(135deg, #e3f2fd, #f1f8e9);
}

h2 {
  color: #1976d2;
  text-align: center;
  margin-bottom: 25px;
  font-size: 2em;
  font-weight: 600;
}

.error {
  color: #d32f2f;
  background: #ffebee;
  border: 1px solid #f44336;
  padding: 10px 15px;
  border-radius: 6px;
  text-align: center;
  font-weight: 500;
}

.warning {
  color: #f57c00;
  background: #fff3e0;
  border: 1px solid #ffb74d;
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 20px;
  text-align: center;
}

.btn-primary {
  background-color: #1976d2;
  color: white;
  border: none;
  padding: 12px 25px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  transition: background-color 0.3s, transform 0.1s;
  box-shadow: 0 3px 8px rgba(25, 118, 210, 0.25);
}
.btn-primary:hover {
  background-color: #1565c0;
  transform: translateY(-1px);
}

.btn-secondary {
  background-color: #9e9e9e;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
}
.btn-secondary:hover {
  background-color: #757575;
}

.list-container {
  background: #fafafa;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  margin-top: 20px;
}

.list-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  border-bottom: 1px solid #eee;
  cursor: pointer;
  transition: background-color 0.2s, box-shadow 0.2s;
}
.list-item:hover {
  background-color: #e3f2fd;
  box-shadow: inset 4px 0 0 #1976d2;
}
.view-details {
  font-size: 0.9em;
  color: #1565c0;
  font-weight: 500;
}

/* MODALS */
.modal {
  position: fixed;
  z-index: 1000;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(50, 50, 50, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background-color: white;
  padding: 30px;
  border-radius: 15px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* FORM ELEMENTS */
.form-group {
  margin-bottom: 20px;
}
.form-group label {
  display: block;
  margin-bottom: 6px;
  font-weight: 600;
  color: #444;
}
.form-group input,
.form-group select {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 1em;
  transition: border-color 0.3s;
}
.form-group input:focus,
.form-group select:focus {
  border-color: #1976d2;
  outline: none;
  box-shadow: 0 0 0 2px rgba(25, 118, 210, 0.2);
}

.split-group {
  background-color: #f9f9f9;
  border-radius: 10px;
  padding: 15px;
}

.checkbox-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 10px;
}

.checkbox-item {
  display: block;
  padding: 10px 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background-color: white;
  cursor: pointer;
  user-select: none;
  transition: all 0.2s ease;
  text-align: left;
  font-weight: 500;
  color: #333;
}

.checkbox-item.selected {
  background-color: #e3f2fd;
  border-color: #1976d2;
  color: #0d47a1;
}

.checkbox-item input[type='checkbox'] {
  display: none;
}

.warning-small {
  font-size: 0.9em;
  color: #f57c00;
  margin-top: 8px;
}


/* DETAILS MODAL */
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 2px solid #eee;
  padding-bottom: 10px;
  margin-bottom: 20px;
}
.close-btn {
  font-size: 1.8rem;
  background: none;
  border: none;
  color: #888;
  cursor: pointer;
}
.close-btn:hover {
  color: #333;
}

.details-list {
  font-size: 1em;
}
.details-list .detail-item {
  margin-bottom: 10px;
  padding-bottom: 8px;
  border-bottom: 1px dashed #e0e0e0;
}
.details-list strong {
  display: inline-block;
  width: 140px;
  color: #333;
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 25px;
}
</style>
