// src/services/expense.service.js

import apiClient from './api.service';

class ExpenseService {
    // Fetches the list of all expenses
    getAll() {
        return apiClient.get('/expenses');
    }

    // Creates a new expense
    create(expense) {
        // 'expense' object must match the structure expected by your Spring Boot @RequestBody
        return apiClient.post('/expenses', expense);
    }
    
    // You can add more methods here like getSummary()
}

export default new ExpenseService();